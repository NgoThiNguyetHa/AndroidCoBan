package hantnph28876.fpoly.demoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    private EditText edName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Log.i("vongdoi","onCreate");
        edName = findViewById(R.id.edName); //ánh xạ editText từ file xml sang
        btn = findViewById(R.id.btnClick); //ánh xạ button từ file xml sang
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //xử lý sự kiện click vào button ở đây
                String contend = edName.getText().toString().trim();//hàng hóa- lấy dữ liệu từ ô nhập
                Intent mIntent = new Intent(MainActivity.this, MainActivity2.class);//tạo ra ông đưa thư
                Bundle tui = new Bundle(); //tạo ra túi đựng thư
                tui.putString("contend",contend); //bỏ dữ liệu vào túi
                mIntent.putExtras(tui); //đưa túi dữ liệu cho ông đưa thư
                startActivity(mIntent);//cho ông này lên tàu
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("vongdoi","onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("vongdoi","onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("vongdoi","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("vongdoi","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("vongdoi","onDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("vongdoi","onRestart");
    }
}