package hantnph28876.fpoly.demoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private TextView tvName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tvName = findViewById(R.id.tvName);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            String s = bundle.getString("contend");
            tvName.setText(s);
        }
    }
}