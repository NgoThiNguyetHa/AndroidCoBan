package hantnph28876.fpoly.asignment.object;

public class SvObject {
    private int stt;
    private String maLop;
    private String tenSv;
    private String ngaySinh;

    public SvObject() {
    }

    public SvObject(int stt, String maLop, String tenSv, String ngaySinh) {
        this.stt = stt;
        this.maLop = maLop;
        this.tenSv = tenSv;
        this.ngaySinh = ngaySinh;
    }

    public int getStt() {
        return stt;
    }

    public void setStt(int stt) {
        this.stt = stt;
    }

    public String getMaLop() {
        return maLop;
    }

    public void setMaLop(String maLop) {
        this.maLop = maLop;
    }

    public String getTenSv() {
        return tenSv;
    }

    public void setTenSv(String tenSv) {
        this.tenSv = tenSv;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }
}
