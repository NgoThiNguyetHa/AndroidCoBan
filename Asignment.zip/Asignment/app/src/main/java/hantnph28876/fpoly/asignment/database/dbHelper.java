package hantnph28876.fpoly.asignment.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME ="danhSachLop";
    public static final int DB_VERSION = 1;

    public dbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createtable = "CREATE TABLE lop(" +
                                "stt INTEGER PRIMARY KEY AUTOINCREMENT,"+
                                "maLop TEXT NOT NULL," +
                                "tenLop TEXT NOT NULL)";
        sqLiteDatabase.execSQL(createtable);
        createtable = "CREATE TABLE sinhvien("+
                                "stt INTEGER PRIMARY KEY AUTOINCREMENT,"+
                                "maLop TEXT NOT NULL,"+
                                "tenSv TEXT NOT NULL,"+
                                "ngaySinh TEXT NOT NULL)";
        sqLiteDatabase.execSQL(createtable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
