package hantnph28876.fpoly.asignment.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import hantnph28876.fpoly.asignment.database.dbHelper;
import hantnph28876.fpoly.asignment.object.SvObject;

public class SvDAO {
    SQLiteDatabase db;

    public SvDAO(Context mContext) {
        dbHelper dpHelper = new dbHelper(mContext);
        db = dpHelper.getWritableDatabase();
    }
    public long insertSv(SvObject obj){
        ContentValues values = new ContentValues();
        values.put("maLop", obj.getMaLop());
        values.put("tenSv", obj.getTenSv());
        values.put("ngaySinh", obj.getNgaySinh());
        return db.insert("sinhvien", null, values);
    }
    public int updateSv(SvObject obj){
        ContentValues values = new ContentValues();
        values.put("maLop", obj.getMaLop());
        values.put("tenSv", obj.getTenSv());
        values.put("ngaySinh", obj.getNgaySinh());
        return db.update("sinhvien", values, "stt=?", new String[]{obj.getStt()+""});
    }
    public int deleteSv(SvObject obj){
        return db.delete("sinhvien", "stt=?", new String[]{obj.getStt()+""});
    }
    public SvObject getByStt(int stt) {
        SvObject obj = new SvObject();

        Cursor cursor = db.rawQuery("SELECT * FROM sinhvien WHERE stt = ?", new String[] {stt + ""});

        if(cursor.moveToFirst()) {
            obj.setStt(cursor.getInt(0));
            obj.setMaLop(cursor.getString(1));
            obj.setTenSv(cursor.getString(2));
            obj.setNgaySinh(cursor.getString(3));

        }
        return obj;
    }
    public ArrayList<SvObject> selectAll() {
        ArrayList<SvObject> list = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM sinhvien", null);

        if(cursor.moveToFirst()) {
            while(!cursor.isAfterLast()) {
                SvObject sv = new SvObject();
                sv.setStt(cursor.getInt(0));
                sv.setMaLop(cursor.getString(1));
                sv.setTenSv(cursor.getString(2));
                sv.setNgaySinh(cursor.getString(3));

                list.add(sv);

                cursor.moveToNext();
            }
        }

        return list;
    }
}
