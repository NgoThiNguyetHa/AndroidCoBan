package hantnph28876.fpoly.asignment.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import hantnph28876.fpoly.asignment.database.dbHelper;
import hantnph28876.fpoly.asignment.object.LopObject;

public class LopDAO {
    private SQLiteDatabase db;

    public LopDAO(Context mContext) {
        dbHelper dbHelper = new dbHelper(mContext);
        db = dbHelper.getWritableDatabase();//cấp quyền edit, update, delete,insert vào bảng
    }



    public long insertLop(LopObject obj){
        ContentValues value = new ContentValues();
        value.put("maLop", obj.getMaLop());
        value.put("tenLop", obj.getTenLop());
        return db.insert("lop", null, value);
    }
    public int updateLop(LopObject obj){
        ContentValues values = new ContentValues();
        values.put("maLop", obj.getMaLop());
        values.put("tenLop", obj.getTenLop());
        return db.update("lop", values, "stt=?", new String[]{String.valueOf(obj.getId())});
    }
    
    public void deleteLop( LopObject obj){
        db.delete("lop","stt=?", new String[]{ obj.getId()+"" });

    }
    //lấy theo stt
    public LopObject getObjectByMaLop(String id){
        LopObject obj = new LopObject();
        Cursor cursor = db.rawQuery("SELECT * FROM sinhvien WHERE stt = ?", new String[] { id + ""});
        if(cursor.moveToFirst()) {
            obj.setId(cursor.getInt(0));
            obj.setMaLop(cursor.getString(1));
            obj.setTenLop(cursor.getString(2));
        }
        return obj;
    }
    public ArrayList<LopObject> getAll() {
        ArrayList<LopObject> list = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM lop", null);
        if(cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                LopObject lop = new LopObject();
                lop.setId(cursor.getInt(0));
                lop.setMaLop(cursor.getString(1));
                lop.setTenLop(cursor.getString(2));

                list.add(lop);
                cursor.moveToNext();
            }
        }
        return list;
    }



}
