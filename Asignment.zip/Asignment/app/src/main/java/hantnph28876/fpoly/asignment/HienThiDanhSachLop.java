package hantnph28876.fpoly.asignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import hantnph28876.fpoly.asignment.adapter.LopAdapter;
import hantnph28876.fpoly.asignment.dao.LopDAO;
import hantnph28876.fpoly.asignment.object.LopObject;

public class HienThiDanhSachLop extends AppCompatActivity {
    private ListView mListView;
    private LopAdapter lopAdapter;
    private ArrayList<LopObject> arrayList = new ArrayList<>();
    private LopObject lopObject;
    private LopDAO lopDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hien_thi_danh_sach_lop);
        mListView = findViewById(R.id.id_listView);

        lopDao = new LopDAO(this);
        arrayList = lopDao.getAll();
        lopAdapter = new LopAdapter(arrayList);//tạo máy chiếu
        mListView.setAdapter(lopAdapter);//chiếu máy chiếu vào màn hình chiếu


        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                deleteLop(arrayList.get(i).getId());

                return false;
            }
        });
    }
    @Override
    protected void onResume() {
        lopDao = new LopDAO(this);
        arrayList = lopDao.getAll();
        lopAdapter = new LopAdapter(arrayList);

        mListView.setAdapter(lopAdapter);
        super.onResume();
    }


    public void deleteLop(int stt){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete");
        builder.setMessage("Bạn có đồng ý muốn xóa không?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                LopObject obj = new LopObject();
                obj.setId(stt);
                lopDao.deleteLop(obj);
                Toast.makeText(HienThiDanhSachLop.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                onResume();

            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();
    }

}