package hantnph28876.fpoly.asignment.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import hantnph28876.fpoly.asignment.object.LopObject;
import hantnph28876.fpoly.asignment.R;

public class LopAdapter extends BaseAdapter {

    private ArrayList<LopObject> listLop;

    public LopAdapter(ArrayList<LopObject> listLop) {
        this.listLop = listLop;
    }
//    public LopAdapter(Context context) {
//        this.context = context;
//
//    }



//    public void setData(ArrayList<LopObject> listLop){
//        this.listLop = listLop;
//        notifyDataSetInvalidated();
//    }
//    public final class viewHolder{
//
//        private TextView tvMaLop, tvTenLop, tvSttLop;
//
//        public viewHolder() {
//        }
//    }
    @Override
    public int getCount() {
        return listLop.size();
    }

    @Override
    public Object getItem(int i) {
        return listLop.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(view == null){
            view = View.inflate(viewGroup.getContext(), R.layout.layout_item_listview,null);

        }
        TextView tvSttLop= view.findViewById(R.id.tvSttLop);
        TextView tvMaLop = view.findViewById(R.id.tvMaLop);
        TextView tvTenLop = view.findViewById(R.id.tvTenLop);

        LopObject object = listLop.get(i);

        tvSttLop.setText(object.getId()+"");
        tvMaLop.setText(object.getMaLop());
        tvTenLop.setText(object.getTenLop());

        return view;
    }
}
