package hantnph28876.fpoly.asignment.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import hantnph28876.fpoly.asignment.R;
import hantnph28876.fpoly.asignment.object.SvObject;

public class SvAdapter extends BaseAdapter {

    private ArrayList<SvObject> listSV;

    public SvAdapter(ArrayList<SvObject> listSV) {
        this.listSV = listSV;
    }

//    public void setData(ArrayList<SvObject> listSV){
//        this.listSV= listSV;
//        notifyDataSetChanged();
//    }
//    public final class MyViewHolder{
//        private TextView tvSttSv, tvTenSv, tvNgaySinh, tvLop;
//
//        public MyViewHolder() {
//        }
//    }
    @Override
    public int getCount() {
        return listSV.size();
    }

    @Override
    public Object getItem(int i) {
        return listSV.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null) {
            view = View.inflate(viewGroup.getContext(), R.layout.layout_item_sinhvien, null);
        }

        TextView tvSttSv = view.findViewById(R.id.tvSttSv);
        TextView tvMaLopSv = view.findViewById(R.id.tvMaLop);
        TextView tvTenSv = view.findViewById(R.id.tvTenSv);
        TextView tvNgaySinhSv = view.findViewById(R.id.tvNgaySinh);


        SvObject obj = listSV.get(i);

        tvSttSv.setText(obj.getStt() + "");
//        tvMaLopSv.setText(obj.getMaLop());
        tvTenSv.setText(obj.getTenSv());
        tvNgaySinhSv.setText(obj.getNgaySinh());



        return view;

    }
}
