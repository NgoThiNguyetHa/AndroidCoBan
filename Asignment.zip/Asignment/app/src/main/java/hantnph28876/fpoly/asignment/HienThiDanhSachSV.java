package hantnph28876.fpoly.asignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import hantnph28876.fpoly.asignment.adapter.LopAdapter;
import hantnph28876.fpoly.asignment.adapter.SvAdapter;
import hantnph28876.fpoly.asignment.dao.LopDAO;
import hantnph28876.fpoly.asignment.dao.SvDAO;
import hantnph28876.fpoly.asignment.object.LopObject;
import hantnph28876.fpoly.asignment.object.SvObject;

public class HienThiDanhSachSV extends AppCompatActivity {
    private ArrayList<SvObject> arrayList = new ArrayList<>();
    private ListView viewSV;
    private Button btnThemSv;
    private SvAdapter adapter;
    private LopDAO lopDAO;
    private SvDAO svDAO;
    private EditText edTen, edNgaySinh;
    private Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hien_thi_danh_sach_sv);
        btnThemSv = findViewById(R.id.btnThemSV);
        spinner = findViewById(R.id.spn_class);
        edTen = findViewById(R.id.edTenSV);
        edNgaySinh = findViewById(R.id.edNgaySinh);
        viewSV = findViewById(R.id.id_listSV);

        lopDAO = new LopDAO(this);
        getDataSpinner(spinner);
        svDAO = new SvDAO(this);
        arrayList = svDAO.selectAll();
        adapter = new SvAdapter(arrayList);
        viewSV.setAdapter(adapter);

        btnThemSv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HashMap<String, String> hashMap = (HashMap<String, String>) spinner.getSelectedItem();
//                Toast.makeText(HienThiDanhSachSV.this, "Mã lớp "+ hashMap.get("maLop"), Toast.LENGTH_SHORT).show();
                SvObject svObject = new SvObject();
                svObject.setMaLop(spinner.getSelectedItem().toString());
                svObject.setTenSv(edTen.getText().toString());
                svObject.setNgaySinh(edNgaySinh.getText().toString());
                if(svDAO.insertSv(svObject) >0){
                    arrayList = svDAO.selectAll();
                    adapter = new SvAdapter(arrayList);
                    viewSV.setAdapter(adapter);
                    Toast.makeText(getApplicationContext(),"Thêm sv thành công", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getApplicationContext(),"Thêm sv không thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });
        viewSV.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                deleteSV(arrayList.get(i).getStt());
                return false;
            }
        });



    }

    private void getDataSpinner(Spinner spinner){
        ArrayList<LopObject> listLop = lopDAO.getAll();
        ArrayList<HashMap<String, String>> list = new ArrayList<>();
        for (LopObject obj: listLop){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("maLop", obj.getMaLop());
            hashMap.put("tenLop", obj.getTenLop());
            list.add(hashMap);
        }

        SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.layout_item_spinner,
                                                    new String[]{"tenLop"}, new int[]{R.id.tvTenLop});
        spinner.setAdapter(adapter);
    }
    @Override
    protected void onResume() {
        svDAO = new SvDAO(this);
        arrayList = svDAO.selectAll();
        adapter = new SvAdapter(arrayList);

        viewSV.setAdapter(adapter);
        super.onResume();
    }
    public void deleteSV(int stt){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete");
        builder.setMessage("Bạn có đồng ý muốn xóa không?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                SvObject obj = new SvObject();
                obj.setStt(stt);
                svDAO.deleteSv(obj);
                Toast.makeText(HienThiDanhSachSV.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                onResume();

            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();
    }

    }
