package hantnph28876.fpoly.asignment;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import hantnph28876.fpoly.asignment.adapter.LopAdapter;
import hantnph28876.fpoly.asignment.dao.LopDAO;
import hantnph28876.fpoly.asignment.object.LopObject;

public class MainActivity extends AppCompatActivity {
    private Button btnThem, btnXemDS, btnQuanLySV;
    private LopDAO dao;
    private LopAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnThem = findViewById(R.id.btnThem);
        btnXemDS = findViewById(R.id.btnXemDS);
        btnQuanLySV = findViewById(R.id.btnQuanLySV);
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogThem();
            }
        });

        btnXemDS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity.this, HienThiDanhSachLop.class);
                startActivity(mIntent);
            }
        });

        btnQuanLySV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity.this, HienThiDanhSachSV.class);
                startActivity(mIntent);
            }
        });
    }
    public void dialogThem(){
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.activity_them_lop);

        EditText edMaLop = dialog.findViewById(R.id.edMaLop);
        EditText edTenlop = dialog.findViewById(R.id.edTenLop);
        Button btnXoaTrang = dialog.findViewById(R.id.btnXoaTrang);
        Button btnLuuLop = dialog.findViewById(R.id.btnLuuLop);
        dao = new LopDAO(this);
        btnLuuLop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LopObject lopObject = new LopObject();
                lopObject.setMaLop(edMaLop.getText().toString());
                lopObject.setTenLop(edTenlop.getText().toString());

                if(dao.insertLop(lopObject) >0){
                    Toast.makeText(getApplicationContext(),"Thêm lớp thành công", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getApplicationContext(),"Thêm lớp không thành công", Toast.LENGTH_SHORT).show();

                }



            }
        });

        btnXoaTrang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edMaLop.setText("");
                edTenlop.setText("");
            }
        });
        dialog.show();
    }
}