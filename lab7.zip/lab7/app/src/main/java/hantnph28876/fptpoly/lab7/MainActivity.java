package hantnph28876.fptpoly.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private EditText edName, edPassword;
    private CheckBox chkRemember;
    private Button btnLogin;
    private SharedPreferences mPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edName = findViewById(R.id.edName);
        edPassword = findViewById(R.id.edPassword);
        chkRemember = findViewById(R.id.chkRemember);
        btnLogin = findViewById(R.id.btnLogin);


        mPreferences = getSharedPreferences("fileLogin", MODE_PRIVATE);
        edName.setText(mPreferences.getString("userName",""));
        edPassword.setText(mPreferences.getString("password",""));
        chkRemember.setChecked(mPreferences.getBoolean("checked", false));

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity.this, MainActivity2.class);
                String name = edName.getText().toString();
                String password = edPassword.getText().toString();
                if(name.equals("nguyetha") && password.equals("12345")){
                    Toast.makeText(getApplicationContext(), "Đăng nhập thành công", Toast.LENGTH_SHORT).show();

                    if(chkRemember.isChecked()){
                        SharedPreferences.Editor editor = mPreferences.edit();
                        editor.putString("userName", name);
                        editor.putString("password", password);
                        editor.putBoolean("checked", true);
                        editor.commit();
                    }else{
                        SharedPreferences.Editor editor = mPreferences.edit();
                        editor.clear();
                        editor.commit();
                    }
                    startActivity(mIntent);

                }else{
                    Toast.makeText(getApplicationContext(), "Đăng nhập không thành công", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

}