package hantnph28876.fptpoly.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainActivity2 extends AppCompatActivity {
    private EditText edNhap;
    private Button btnSave, btnShow;
    private TextView tvHienThi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edNhap = findViewById(R.id.edNhap);
        btnSave = findViewById(R.id.btnSave);
        btnShow = findViewById(R.id.btnShow);
        tvHienThi = findViewById(R.id.edHienThi);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(createCache()){
                    Toast.makeText(MainActivity2.this, "Lưu thành công", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(MainActivity2.this, "Lưu không thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(readCache()){
                    Toast.makeText(MainActivity2.this, "Show thành công", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(MainActivity2.this, "Show không thành công", Toast.LENGTH_SHORT).show();

                }

                //loadAllCache();
            }
        });
    }
    public boolean createCache(){

        try {
            //lấy đường dẫn thư mục cache
            File pathCacheDir = getCacheDir();
            String strCacheFileName = "cacheFile.cache";
            String strFileContents = edNhap.getText()+"";
            //tạo file cache
            File newCacheFile = new File(pathCacheDir, strCacheFileName);
            //tạo mới file trống trong thư mục cache
            newCacheFile.createNewFile();
            //tiến hành ghi file
            FileOutputStream fos = new FileOutputStream(newCacheFile.getAbsolutePath());
            fos.write(strFileContents.getBytes());
            fos.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }
    public boolean readCache(){

        try {
            File pathCacheDir = getCacheDir();
            String strCacheFileName = "cacheFile.cache";
            File newCacheFile = new File(pathCacheDir, strCacheFileName);
            //tiến hành đọc file
            Scanner sc = new Scanner(newCacheFile);
            String data = "";
            while (sc.hasNext()){
                data+= sc.nextLine()+"\n";
            }
            tvHienThi.setText(data);
            sc.close();
            Toast.makeText(getBaseContext(), "ND: "+data, Toast.LENGTH_SHORT).show();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }
//    public void loadAllCache (){
//        File pathCacheDir = getCacheDir();
//        File []listCache = pathCacheDir.listFiles();
//        for (File f: listCache){
//            f.delete();
//        }
//    }
}