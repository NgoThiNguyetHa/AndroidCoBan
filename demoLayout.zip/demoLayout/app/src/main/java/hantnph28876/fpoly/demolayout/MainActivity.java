package hantnph28876.fpoly.demolayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edUser, edPass;
    private Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constrainlayout);
        edPass = findViewById(R.id.edPassword);
        edUser = findViewById(R.id.edUsername);
        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edPass.getText().toString().equals("nguyenloc")&&
                        edUser.getText().toString().equals("nguyenloc")){
                    Toast.makeText(getApplicationContext(), "thành công", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}