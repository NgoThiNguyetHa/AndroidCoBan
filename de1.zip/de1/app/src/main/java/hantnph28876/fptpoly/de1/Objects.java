package hantnph28876.fptpoly.de1;

import java.io.Serializable;

public class Objects implements Serializable {
    private int id;
    private String noiDung;
    private String thoiGian;
    private int imgDelete;

    public Objects() {
    }

    public Objects(int id, String noiDung, String thoiGian) {
        this.id = id;
        this.noiDung = noiDung;
        this.thoiGian = thoiGian;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public String getThoiGian() {
        return thoiGian;
    }

    public void setThoiGian(String thoiGian) {
        this.thoiGian = thoiGian;
    }

    public int getImgDelete() {
        return imgDelete;
    }

    public void setImgDelete(int imgDelete) {
        this.imgDelete = imgDelete;
    }
}
