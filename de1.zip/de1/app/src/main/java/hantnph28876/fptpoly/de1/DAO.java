package hantnph28876.fptpoly.de1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DAO {
    private SQLiteDatabase db;

    public DAO(Context mContext) {
        dbHelper dbHelper = new dbHelper(mContext);
        db = dbHelper.getWritableDatabase();
    }
    //insert
    public long insertObj(Objects obj){
        ContentValues values = new ContentValues();
        values.put("noiDung", obj.getNoiDung());
        values.put("thoiGian", obj.getThoiGian());
        return db.insert("ghinho", null, values);
    }
    //update
    public int updateObj(Objects obj){
        ContentValues values = new ContentValues();
        values.put("noiDung", obj.getNoiDung());
        values.put("thoiGian", obj.getThoiGian());
        String id = String.valueOf(obj.getId());
        return db.update("ghinho", values, "id=?", new String[]{id});

    }
    //delete
    public int deleteObj(Objects obj){
        String id = String.valueOf(obj.getId());
        return db.delete("ghinho", "id=?", new String[]{id});
    }
    //getAll
    public List<Objects> getAll(){
        String sql="SELECT * FROM ghinho";
        return getData(sql);
    }

    @SuppressLint("Range")
    private List<Objects> getData(String sql, String...SelectArgs) {
        List<Objects> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql,SelectArgs);
        while (cursor.moveToNext()){
            Objects obj = new Objects();
            obj.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex("id"))));
            obj.setNoiDung(cursor.getString(cursor.getColumnIndex("noiDung")));
            obj.setThoiGian(cursor.getString(cursor.getColumnIndex("thoiGian")));
            list.add(obj);
        }
        return list;
    }
}
