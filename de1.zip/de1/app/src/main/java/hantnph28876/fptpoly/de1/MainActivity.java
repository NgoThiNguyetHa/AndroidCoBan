package hantnph28876.fptpoly.de1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {
    private ListView mListView;
    private Button btnThem;
    private ArrayList<Objects> list = new ArrayList<>();
    private DAO dao;
    private Adapter adapter;
    private Objects obj;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = findViewById(R.id.idListView);
        btnThem = findViewById(R.id.btnThemGhiChu);
        //laays list từ dao
        dao= new DAO(this);
        list = (ArrayList<Objects>) dao.getAll();
        adapter= new Adapter(getApplicationContext(), new DeleteInterface() {
            @Override
            public void onClickDelete(int index) {
                deleteDialog(index);
            }
        });
        adapter.setData(list);
        mListView.setAdapter(adapter);

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity.this,MainActivity2.class );
                startActivity(mIntent);

            }
        });
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(MainActivity.this, MainActivity3.class);
                Bundle bundle = new Bundle(); //tạo cái để đóng gói dữ liệu
                bundle.putSerializable("obj", list.get(i));
                mIntent.putExtras(bundle);
                startActivity(mIntent);
            }
        });

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                updateDialog(i);
                return false;
            }
        });

    }
    public  void deleteDialog(int index){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Bạn có chắc chắn muốn xóa?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(dao.deleteObj(list.get(index)) >0){
                    list.remove(index); //xóa đối tượng ở vị trí index
                    adapter.setData(list);
                    Toast.makeText(MainActivity.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();
    }

    public void updateDialog(int index){

        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.layout_update);

        EditText edNoiDung = findViewById(R.id.edNoiDung);
        EditText edThoiGian = findViewById(R.id.edThoiGian);
        Button btnUpdate = findViewById(R.id.btnUpdate);



        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dao = new DAO(getApplicationContext());
                obj.setNoiDung(edNoiDung.getText().toString());
                obj.setThoiGian(edThoiGian.getText().toString());
                if(dao.updateObj(obj) >0){
                    Toast.makeText(MainActivity.this, "update thành công", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "update không thành công", Toast.LENGTH_SHORT).show();
                }

            }
        });
        dialog.show();

    }
}