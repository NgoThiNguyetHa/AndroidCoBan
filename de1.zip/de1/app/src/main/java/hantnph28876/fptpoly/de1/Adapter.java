package hantnph28876.fptpoly.de1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends BaseAdapter {
    private ArrayList<Objects> list;
    private Context mContext;
    private DeleteInterface deleteInterface;

    public Adapter(Context mContext, DeleteInterface deleteInterface) {
        this.mContext = mContext;
        this.deleteInterface = deleteInterface;
    }
    public void setData(ArrayList<Objects> list){
        this.list = list;
        notifyDataSetChanged();
    }
    public static class ViewHolder{
        private TextView noiDung;
        private TextView thoiGian;
        private ImageView imgDelete;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if(view == null){
            viewHolder = new ViewHolder();
            LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = mInflater.inflate(R.layout.layout_item, null);
            viewHolder.noiDung = view.findViewById(R.id.tvNoiDung);
            viewHolder.thoiGian = view.findViewById(R.id.tvThoiGian);
            viewHolder.imgDelete = view.findViewById(R.id.imgDelete);
            view.setTag(viewHolder);

        }else {
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.noiDung.setText(list.get(i).getNoiDung());
        viewHolder.thoiGian.setText(list.get(i).getThoiGian());
        viewHolder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteInterface.onClickDelete(i);
            }
        });
        return view;
    }
}
