package hantnph28876.fptpoly.de1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    private TextView tvContent, tvTime;
    private DAO dao;
    private Objects obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tvContent= findViewById(R.id.tvContent);
        tvTime= findViewById(R.id.tvTime);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            obj = (Objects) bundle.getSerializable("obj");
            tvContent.setText(obj.getNoiDung());
            tvTime.setText(obj.getThoiGian());
        }
    }
}