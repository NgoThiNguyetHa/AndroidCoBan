package hantnph28876.fptpoly.de1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private EditText edNoiDung, edThoiGian;
    private Button btnGhiNho;
    private DAO dao;
    private  Objects obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edNoiDung = findViewById(R.id.edNoiDung);
        edThoiGian = findViewById(R.id.edThoiGian);
        btnGhiNho = findViewById(R.id.btnGhiNho);

        btnGhiNho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edNoiDung.getText().toString().length() == 0 ||
                    edThoiGian.getText().toString().length() == 0){
                    Toast.makeText(MainActivity2.this, "Chưa nhập đủ", Toast.LENGTH_SHORT).show();
                }else{
                    obj = new Objects();
                    obj.setNoiDung(edNoiDung.getText().toString());
                    obj.setThoiGian(edThoiGian.getText().toString());
                    dao = new DAO(getApplicationContext());
                    if(dao.insertObj(obj) >0){
                        Toast.makeText(MainActivity2.this, "Ghi nhớ thành công", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity2.this, "Ghi nhớ không thành công", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}