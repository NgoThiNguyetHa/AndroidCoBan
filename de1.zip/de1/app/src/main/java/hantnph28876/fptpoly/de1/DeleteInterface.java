package hantnph28876.fptpoly.de1;

public interface DeleteInterface {
    void onClickDelete(int index);
}
