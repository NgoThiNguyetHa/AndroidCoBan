package hantnph28876.fptpoly.lab3_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private MyAdapter myAdapter;
    private ArrayList<MyObject> arrayList = new ArrayList<>();//tạo ra máy tính
    private MyObject myObject;
    private Intent mIntent;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.id_listview);
        myAdapter = new MyAdapter(this);
        context = this;
        for (int i=0; i<10;i++){
            myObject = new MyObject(R.drawable.ic_phone, "Hà"+i, "0860202545"+i);
            arrayList.add(myObject);
        }
        myAdapter.setData(arrayList); //cắm máy tính vào máy chiếu để truyền dữ liệu vào máy chiếu
        listView.setAdapter(myAdapter);//chiếu máy chiếu vào màn hình chiếu
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mIntent = new Intent(context, MainActivity2.class);
                String hoTen = arrayList.get(i).getName();
                String sdt = arrayList.get(i).getSdt();
                mIntent.putExtra("name",hoTen);
                mIntent.putExtra("phone", sdt);
                startActivity(mIntent);
            }
        });

    }
}