package hantnph28876.fptpoly.lab3_4;

public class MyObject {
    private int img;
    private String name;
    private String sdt;

    public MyObject(int img, String name, String sdt) {
        this.img = img;
        this.name = name;
        this.sdt = sdt;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String address) {
        this.sdt = sdt;
    }

}
