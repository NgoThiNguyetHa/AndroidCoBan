package hantnph28876.fptpoly.lab3_4;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
   private Context mContext;
    private ArrayList<MyObject> arrayList;

    public MyAdapter(Context mContext) {
        this.mContext = mContext;
    }
    public  void  setData(ArrayList<MyObject> arrayList){
            this.arrayList= arrayList;
            notifyDataSetChanged(); //có tác dụng refesh mọi adapter
    }
    public final class MyViewHolder{
        //khai báo các thành phần view có trong layoutItem
        private ImageView img_avata;
        private TextView tvName;
        private TextView tvSdt;
        public MyViewHolder(){

        }

    }
    @Override
    public int getCount() {
        //thông báo cho biết có bao nhiêu item hiện ra
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        MyViewHolder viewHolder =null;
        LayoutInflater mInflater= ((Activity)mContext).getLayoutInflater();
        if(view == null){
            viewHolder= new MyViewHolder();
            //cả 1 item là 1 view
            //inflate dùng để gom các layout_item_listview thành 1 view
            view = mInflater.inflate(R.layout.layout_item_listview, null);
            //ánh xạ
            viewHolder.img_avata = view.findViewById(R.id.id_avatar);

            viewHolder.tvName = view.findViewById(R.id.tvName);
            viewHolder.tvSdt = view.findViewById(R.id.tvSdt);
            view.setTag(viewHolder);
        }else {
            viewHolder = (MyViewHolder) view.getTag();
        }
        //set dữ liệu từ arrayList
        viewHolder.tvSdt.setText(arrayList.get(i).getSdt());
        viewHolder.tvName.setText(arrayList.get(i).getName());
        viewHolder.img_avata.setImageResource(arrayList.get(i).getImg());

        return view;
    }
}
