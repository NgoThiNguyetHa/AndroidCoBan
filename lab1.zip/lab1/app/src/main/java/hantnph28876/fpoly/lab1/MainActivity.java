package hantnph28876.fpoly.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edName;
    private EditText edPass;
    private Button btn1;
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edName = findViewById(R.id.edName);
        edPass = findViewById(R.id.edPass);
        btn1 = findViewById(R.id.btnLogin);
        btn2 = findViewById(R.id.btnHuy);

        btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(edName.getText().toString().equals("fptpolytechnic") &&
                                edPass.getText().toString().equals("123456789")){
                            Toast.makeText(getApplicationContext(), "Thành công", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(), "Không thành công", Toast.LENGTH_SHORT).show();
                    }
}      });

    }
}