package hantnph28876.fpoly.demosqlite.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME="danhsach";
    public static final int DB_VERSION=1;
    public DbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //hàm onCreate này chỉ chạy 1 lần
        String createtable ="CREATE TABLE nhanvien("+"id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL,"+"address TEXT NOT NULL)";
        sqLiteDatabase.execSQL(createtable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //hàm này sẽ chạy khi version thay đổi
        String updateTable="DROP TABLE IF EXISTS nhanvien";//xóa bảng nhanvien khi tồn tại
        sqLiteDatabase.execSQL(updateTable);
        onCreate(sqLiteDatabase);//gọi lại hàm onCreate để tạo lại bảng mới
    }
}
