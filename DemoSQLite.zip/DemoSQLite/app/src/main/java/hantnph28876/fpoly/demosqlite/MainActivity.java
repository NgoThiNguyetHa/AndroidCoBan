package hantnph28876.fpoly.demosqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import hantnph28876.fpoly.demosqlite.dao.NhanvienDAO;
import hantnph28876.fpoly.demosqlite.object.MyObject;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextInputEditText edName, edAddress;
    private Button btnSave, btnShow;
    private MyObject object;
    private NhanvienDAO nhanvienDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edName = findViewById(R.id.edName);
        edAddress = findViewById(R.id.edAddress);
        btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(this); //đăng ký sự kiện click
        btnShow = findViewById(R.id.btnShow);
        btnShow.setOnClickListener(this); //đăng ký sự kiện click
        /*btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnSave:
                //xử lí sự kiện nhấn nút save
                object = new MyObject();//tạo ra đối tượng
                object.setName((edName.getText().toString()));
                object.setAddress(edAddress.getText().toString());
                nhanvienDAO = new NhanvienDAO(this);//tạo ra DAO
                //gọi insert và truyền object vào
                if (nhanvienDAO.insertNhanvien(object)>0){
                    Toast.makeText(this, "thành công", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(this, "không thành công", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.btnShow:
                //xử lí sự kiện nhấn nút show
                Intent intent = new Intent(MainActivity.this, DanhSachScreen.class);//tạo ra ông đưa thư

                startActivity(intent);
                break;
        }
    }
}