package hantnph28876.fpoly.demosqlite.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import hantnph28876.fpoly.demosqlite.database.DbHelper;
import hantnph28876.fpoly.demosqlite.object.MyObject;

public class NhanvienDAO {
    private SQLiteDatabase db;

    public NhanvienDAO(Context mContext) {
        DbHelper dbHelper = new DbHelper(mContext);//tạo database và bảng
        db = dbHelper.getWritableDatabase();//cấp quyền edit, update, delete, insert
    }
    //insert
    public long insertNhanvien(MyObject obj){
        ContentValues values = new ContentValues();//tạo khuôn của bảng
        values.put("name", obj.getName());//đổ tên vào ô name của khuôn
        values.put("address", obj.getAddress());//đổ địa chỉ vào ô name của khuôn
        return db.insert("nhanvien", null,values);
    }
    //update
    public int updateNhanVien(MyObject obj){
        ContentValues values = new ContentValues();//tạo khuôn của bảng
        values.put("name", obj.getName());//đổ tên vào ô name của khuôn
        values.put("address", obj.getAddress());//đổ địa chỉ vào ô name của khuôn
        return db.update("nhanvien", values, "id=?",
                new String[]{String.valueOf(obj.getId())});
    }
    //get all
    public List<MyObject>getAll(){
        String sql = "SELECT * FROM nhanvien";
        return  getData(sql);
    }
    //get 1 object by id
    public MyObject getObjectById(String id){
        String sql = "SELECT * FROM nhanvien WHERE id=?";
        List<MyObject> list = getData(sql, id);
        return list.get(0);
    }
    //delete
    public int deleteNhanVien(MyObject obj){

        return db.delete("nhanvien", "id=?", new String[]{String.valueOf(obj.getId())});
    }
    @SuppressLint("Range")
    private List<MyObject> getData(String sql, String...SelectArgs){
        List<MyObject> list = new ArrayList<>();
        Cursor c = db.rawQuery(sql,SelectArgs);//cursor  chính 1 bảng dữ liệu
        while (c.moveToNext()){
            //tạo đối tượng
            MyObject object = new MyObject();
            object.setId( Integer.parseInt(c.getString(c.getColumnIndex("id"))));
            object.setName(c.getString(c.getColumnIndex("name")));//lấy name để set vào
            object.setAddress(c.getString(c.getColumnIndex("address")));//lấy address để set vào
            //thêm vào danh sách
            list.add(object);
        }
        return list;//trả lại 1 list danh sách
    }
}
