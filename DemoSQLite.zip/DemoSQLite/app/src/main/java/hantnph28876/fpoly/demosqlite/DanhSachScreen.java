package hantnph28876.fpoly.demosqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import hantnph28876.fpoly.demosqlite.adapter.MyAdapter;
import hantnph28876.fpoly.demosqlite.dao.NhanvienDAO;
import hantnph28876.fpoly.demosqlite.object.MyObject;

public class DanhSachScreen extends AppCompatActivity {
    private ListView mListView;
    private MyAdapter myAdapter;
    private ArrayList<MyObject> arrayList = new ArrayList<>() ;//tạo ra máy tính
    private MyObject myObject;
    private NhanvienDAO nvDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_screen);
        mListView = findViewById(R.id.id_listView);

        myAdapter = new MyAdapter(this, new InterfaceDeleteListenner() {
            @Override
            public void onclickDelete(int index) {
                if(nvDao.deleteNhanVien(arrayList.get(index)) >0){
                    arrayList.remove(index);
                    myAdapter.setData(arrayList);
                    Toast.makeText(getApplicationContext(),"delete sucess",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"delete fail",Toast.LENGTH_LONG).show();
                }

            }
        });//tạo máy chiếu
//        for (int i=0; i<10;i++){
//            myObject = new MyObject(R.drawable.ic_car, "Nguyễn"+i, "Hà Nội"+i);
//            arrayList.add(myObject);
//        }
        nvDao = new NhanvienDAO(this);
        //lấy dữ liệu từ database đổ vào arrayList
        arrayList= (ArrayList<MyObject>) nvDao.getAll();
        //truyền arrayList vào adapter
        myAdapter.setData(arrayList);
        //setAdapter cho listView
        mListView.setAdapter(myAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                openDialog(arrayList.get(i).getName());//gọi dialog và truyền tên vào cho hàm openDialog
            }
        });
    }
    private void openDialog(String s){
        AlertDialog.Builder diaBuilder = new AlertDialog.Builder(this);
        diaBuilder.setTitle("Thông báo");//tiêu đề
        diaBuilder.setMessage(s);//truyền tên(s) vào phần nội dung của dialog
        diaBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //xử lý sự kiện khi click OK

            }
        });
        diaBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //xử lý sự kiện khi click cancel
            }
        });
        diaBuilder.show();
    }
}