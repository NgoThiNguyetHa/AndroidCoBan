package hantnph28876.fpoly.demosqlite.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import hantnph28876.fpoly.demosqlite.InterfaceDeleteListenner;
import hantnph28876.fpoly.demosqlite.R;
import hantnph28876.fpoly.demosqlite.object.MyObject;

public class MyAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<MyObject> arrayList;
    private InterfaceDeleteListenner deleteListenner;

    public MyAdapter(Context mContext, InterfaceDeleteListenner listenner) {
        this.mContext = mContext;
        this.deleteListenner = listenner;//gán interface
    }
    public  void  setData(ArrayList<MyObject> arrayList){
        this.arrayList= arrayList;
        notifyDataSetChanged(); //có tác dụng refesh mọi adapter
    }
    public final class MyViewHolder{
        //khai báo các thành phần view có trong layoutItem
        private ImageView img_avata;
        private ImageView img_delete;
        private TextView tvName;
        private TextView tvAddress;
        public MyViewHolder(){

        }

    }
    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        MyViewHolder viewHolder =null;
        LayoutInflater mInflater = ((Activity)mContext).getLayoutInflater();
        if(view == null){
            viewHolder = new MyViewHolder();
            view = mInflater.inflate(R.layout.layout_item_listview,null);
            viewHolder.img_avata = view.findViewById(R.id.id_avata);
            viewHolder.img_delete = view.findViewById(R.id.id_delete);
            viewHolder.tvName = view.findViewById(R.id.tvName);
            viewHolder.tvAddress = view.findViewById(R.id.tvAddress);
            view.setTag(viewHolder);

        }else {
            viewHolder = (MyViewHolder) view.getTag();
        }
        //set dữ liệu từ arrayList
        viewHolder.tvAddress.setText(arrayList.get(i).getAddress());
        viewHolder.tvName.setText(arrayList.get(i).getName());

        viewHolder.img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteListenner.onclickDelete(i);
            }
        });
        return view;
    }
}
