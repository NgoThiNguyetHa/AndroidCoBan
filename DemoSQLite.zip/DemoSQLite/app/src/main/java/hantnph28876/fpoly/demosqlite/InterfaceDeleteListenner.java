package hantnph28876.fpoly.demosqlite;

public interface InterfaceDeleteListenner {
    void onclickDelete(int index);//khai báo hàm, k cần định nghĩa
}
