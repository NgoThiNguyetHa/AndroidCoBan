package hantnph28876.fptpoly.onthi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edHoTen, edDiaChi, edNgaySinh;
    private Button btnLuu, btnHienThi;
    private Dao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edHoTen = findViewById(R.id.edHoTen);
        edDiaChi = findViewById(R.id.edDiaChi);
        edNgaySinh = findViewById(R.id.edNgaySinh);
        btnLuu = findViewById(R.id.btnLuu);
        btnHienThi = findViewById(R.id.btnHienThi);



        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edHoTen.getText().toString().length()==0 ||
                    edDiaChi.getText().toString().length() ==0 ||
                    edNgaySinh.getText().toString().length() ==0){
                    Toast.makeText(MainActivity.this, "Chưa nhập đủ", Toast.LENGTH_SHORT).show();
                }else{
                    Object obj = new Object();
                    dao = new Dao(getApplicationContext());
                    obj.setHoTen(edHoTen.getText().toString());
                    obj.setDiaChi(edDiaChi.getText().toString());
                    obj.setNgaySinh(edNgaySinh.getText().toString());

                    if(dao.insert(obj) >0){
                        Toast.makeText(MainActivity.this, "Lưu thành công", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity.this, "Lưu không thành công", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(mIntent);
            }
        });

    }
}