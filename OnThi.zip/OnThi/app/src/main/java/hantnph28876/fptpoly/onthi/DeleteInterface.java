package hantnph28876.fptpoly.onthi;

public interface DeleteInterface {
    public void deleteInterface(int i);
}
