package hantnph28876.fptpoly.onthi;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dpHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "dbSinhVien";
    public static final int DB_VERSION = 1;

    public dpHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create ="create table sinhvien(id integer primary key autoincrement,"+
                        "hoten text not null,"+"diachi text not null,"+
                        "ngaysinh text not null)";
        sqLiteDatabase.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
