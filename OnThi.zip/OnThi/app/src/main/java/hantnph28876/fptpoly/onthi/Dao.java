package hantnph28876.fptpoly.onthi;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Dao {
    private SQLiteDatabase db;

    public Dao(Context mContext) {
        dpHelper dpHelper = new dpHelper(mContext);
        db = dpHelper.getWritableDatabase();
    }
    public long insert(Object obj){
        ContentValues values = new ContentValues();
        values.put("hoten", obj.getHoTen());
        values.put("diachi", obj.getDiaChi());
        values.put("ngaysinh", obj.getNgaySinh());
        return db.insert("sinhvien", null, values);
    }

    public int update(Object obj){
        ContentValues values = new ContentValues();
        values.put("hoten", obj.getHoTen());
        values.put("diachi", obj.getDiaChi());
        values.put("ngaysinh", obj.getNgaySinh());
        return db.update("sinhvien", values, "id=?", new String[]{String.valueOf(obj.getId())});
    }
    public int delete(Object obj){
        return db.delete("sinhvien", "id=?", new String[]{String.valueOf(obj.getId())});
    }
    public List<Object> getAll(){
        String sql = "select * from sinhvien";
        return getData(sql);
    }

    @SuppressLint("Range")
    private List<Object> getData(String sql, String...SelectArgs) {
        List<Object> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, SelectArgs);
        while (cursor.moveToNext()){
            Object obj = new Object();
            obj.setId(cursor.getInt(cursor.getColumnIndex("id")));
            obj.setHoTen(cursor.getString(cursor.getColumnIndex("hoten")));
            obj.setDiaChi(cursor.getString(cursor.getColumnIndex("diachi")));
            obj.setNgaySinh(cursor.getString(cursor.getColumnIndex("ngaysinh")));
            list.add(obj);
        }
        return list;
    }
}
