package hantnph28876.fptpoly.onthi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    private EditText edHoTen, edDiaChi, edNgaySinh;
    private Button btnHuy, btnCapNhat;
    private Dao dao;
    private Object obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        edHoTen = findViewById(R.id.edHoTenEdit);
        edDiaChi = findViewById(R.id.edDiaChiEdit);
        edNgaySinh = findViewById(R.id.edNgaySinhEdit);
        btnHuy = findViewById(R.id.btnHuy);
        btnCapNhat = findViewById(R.id.btnCapNhat);



        Bundle bundle = getIntent().getExtras();
        if(bundle!= null){
            obj = (Object) bundle.getSerializable("obj");
            edHoTen.setText(obj.getHoTen());
            edDiaChi.setText(obj.getDiaChi());
            edNgaySinh.setText(obj.getNgaySinh());

        }

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(mIntent);
            }
        });

        btnCapNhat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edHoTen.getText().toString().length()==0 ||
                        edDiaChi.getText().toString().length() ==0 ||
                        edNgaySinh.getText().toString().length() ==0){
                    Toast.makeText(MainActivity3.this, "Chưa nhập đủ", Toast.LENGTH_SHORT).show();

                }else{

                    dao = new Dao(getApplicationContext());
                    obj.setHoTen(edHoTen.getText().toString());
                    obj.setDiaChi(edDiaChi.getText().toString());
                    obj.setNgaySinh(edNgaySinh.getText().toString());

                    if(dao.update(obj) >0){
                        Toast.makeText(MainActivity3.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity3.this, "Cập nhật không thành công", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}