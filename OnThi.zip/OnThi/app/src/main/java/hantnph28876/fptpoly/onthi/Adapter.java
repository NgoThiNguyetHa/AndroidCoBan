package hantnph28876.fptpoly.onthi;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends BaseAdapter {
    private List<Object> list = new ArrayList<>();
    private Context mContext;
    private DeleteInterface deleteInterface;

    public Adapter(Context mContext, DeleteInterface deleteInterface) {
        this.mContext = mContext;
        this.deleteInterface = deleteInterface;
    }

    public void setData(List<Object> list){
        this.list = list;
        notifyDataSetChanged();
    }
    public static class ViewHolder{
        private TextView tvHoTen, tvDiaChi, tvNgaySinh;
        private ImageView imgDelete;

        public ViewHolder() {
        }
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public java.lang.Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        LayoutInflater inflater = ((Activity)mContext).getLayoutInflater();

        if (view== null){
            viewHolder = new ViewHolder();
            view = inflater.inflate(R.layout.layout_item, null);
            viewHolder.tvHoTen = view.findViewById(R.id.tvHoTen);
            viewHolder.tvDiaChi = view.findViewById(R.id.tvDiaChi);
            viewHolder.tvNgaySinh = view.findViewById(R.id.tvNgaySinh);

            viewHolder.imgDelete = view.findViewById(R.id.imgDelete);
            view.setTag(viewHolder);

        }else{
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.tvHoTen.setText(list.get(i).getHoTen());
        viewHolder.tvDiaChi.setText(list.get(i).getDiaChi());
        viewHolder.tvNgaySinh.setText(list.get(i).getNgaySinh());

        viewHolder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteInterface.deleteInterface(i);
            }
        });
        return view;
    }
}
