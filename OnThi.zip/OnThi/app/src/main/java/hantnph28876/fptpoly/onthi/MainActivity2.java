package hantnph28876.fptpoly.onthi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private ListView mListView;
    private List<Object> list = new ArrayList<>();
    private  Dao dao;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mListView = findViewById(R.id.idListView);

        dao = new Dao(this);
        adapter = new Adapter(this, new DeleteInterface() {
            @Override
            public void deleteInterface(int i) {
                delete(i);

            }
        });

        list = (ArrayList<Object>) dao.getAll();
        adapter.setData(list);
        mListView.setAdapter(adapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);

                Bundle bundle = new Bundle();
                bundle.putSerializable("obj", list.get(i));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public void delete( int index){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete");
        builder.setMessage("Bạn có muốn xóa không?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                if(dao.delete(list.get(index)) > 0){
                    list = dao.getAll();
                    adapter.setData(list);
                    mListView.setAdapter(adapter);
                    Toast.makeText(MainActivity2.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity2.this, "Xóa không thành công "+list.get(index), Toast.LENGTH_LONG).show();
                }
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();
    }
}